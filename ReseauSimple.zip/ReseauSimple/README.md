# LU3IN013_Client_Server
Client-Server communication system Petri net models generator, with scalability by the number of clients and servers

Depencencies: PNML Framework, EMF Ecore, EMF Common, OCL Ecore, OCL Common

Usage:

Pour OS

./compile_os

./cliser_os nb_clients nb_serveurs

OU

./cliser_os_1 nb_clients nb_serveurs

Pour Window

sh compile_win

sh cliser_win nb_clients nb_serveurs

