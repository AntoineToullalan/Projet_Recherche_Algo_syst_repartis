package clientserver;
import fr.lip6.move.pnml.ptnet.hlapi.PageHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.PlaceHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.PositionHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.TransitionHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.AnnotationGraphicsHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.ArcHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.ArcGraphicsHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.DimensionHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.NameHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.NodeGraphicsHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.OffsetHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.PTMarkingHLAPI;
import fr.lip6.move.pnml.ptnet.hlapi.LineHLAPI;
import fr.lip6.move.pnml.ptnet.CSS2Color;
import fr.lip6.move.pnml.framework.utils.exception.InvalidIDException;
import fr.lip6.move.pnml.framework.utils.exception.VoidRepositoryException;

public class Arc {
	private PlaceHLAPI place;
	private TransitionHLAPI transition;
	public Arc(PageHLAPI syspage,int idPlaceSrc, int idTransDset,int idArc) {
		try {
			place = new PlaceHLAPI("place"+idPlaceSrc,syspage);			
			place.setInitialMarkingHLAPI(new PTMarkingHLAPI(1L));
			NodeGraphicsHLAPI pg = new NodeGraphicsHLAPI(place);
			PositionHLAPI pos = new PositionHLAPI(10,10,pg);
			DimensionHLAPI dim = new DimensionHLAPI(25,25,pg);
			OffsetHLAPI o = new OffsetHLAPI(-12,-30,new AnnotationGraphicsHLAPI(new NameHLAPI(place.getId(),place)));
			OffsetHLAPI omk = new OffsetHLAPI(-5,-10,new AnnotationGraphicsHLAPI(place.getInitialMarkingHLAPI()));
			LineHLAPI l = new LineHLAPI(pg);
			l.setColorHLAPI(CSS2Color.OLIVE);
			
			transition = new TransitionHLAPI("transition"+idTransDset,syspage);
			NodeGraphicsHLAPI pg3 = new NodeGraphicsHLAPI(transition);
			PositionHLAPI pos3 = new PositionHLAPI(100,140,pg3);
			DimensionHLAPI dim3 = new DimensionHLAPI(10,25,pg3);
			OffsetHLAPI o3 = new OffsetHLAPI(-30,-30,new AnnotationGraphicsHLAPI(new NameHLAPI(transition.getId(),transition)));
			LineHLAPI l3 = new LineHLAPI(pg3);
			l3.setColorHLAPI(CSS2Color.OLIVE);
			
			ArcHLAPI arc = new ArcHLAPI("arc"+idArc,place,transition,syspage);
			LineHLAPI al1 = new LineHLAPI(new ArcGraphicsHLAPI(arc));
			al1.setColorHLAPI(CSS2Color.OLIVE);
		}
		catch(InvalidIDException e) {
			e.printStackTrace();
		}
		catch (VoidRepositoryException e) {
			e.printStackTrace();	
		}
	}
}
