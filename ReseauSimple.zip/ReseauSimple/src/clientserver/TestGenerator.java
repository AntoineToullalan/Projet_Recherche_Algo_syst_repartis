package clientserver;
public class TestGenerator {

	public static void main (String[] args) {
		
		int idPlace;
		int idTrans;
		int idArc;
		
		try {
			idPlace = Integer.parseInt(args[0]);
			idTrans  = Integer.parseInt(args[1]);
			idArc  = Integer.parseInt(args[2]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Usage: ./cliser_os idPlace idTrans idArc");			
			return;
		}
		
		System.out.println("Model of one Arc ");
		Generator1 gen = new Generator1();
		gen.generate_file(idPlace, idTrans,idArc , 750, 500);

	}
}
